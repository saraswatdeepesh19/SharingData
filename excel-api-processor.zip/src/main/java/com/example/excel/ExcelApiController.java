package com.example.excel;

import org.apache.poi.xssf.usermodel.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.ByteArrayOutputStream;

@RestController
@RequestMapping("/excel")
public class ExcelApiController {

    private final WebClient webClient;

    public ExcelApiController(WebClient webClient) {
        this.webClient = webClient;
    }

    @PostMapping("/upload")
    public ResponseEntity<byte[]> handleExcelUpload(@RequestParam("file") MultipartFile file) throws Exception {
        XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
        XSSFSheet sheet = workbook.getSheetAt(0);

        int apiColumnIndex = 1; // Column B (API URL)
        int responseColumnIndex = 2; // Column C (API response)

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            XSSFRow row = sheet.getRow(i);
            if (row == null) continue;

            XSSFCell apiCell = row.getCell(apiColumnIndex);
            if (apiCell == null) continue;

            String apiUrl = apiCell.getStringCellValue();
            try {
                String response = webClient.get()
                        .uri(apiUrl)
                        .retrieve()
                        .bodyToMono(String.class)
                        .block();

                row.createCell(responseColumnIndex).setCellValue(response);
            } catch (Exception e) {
                row.createCell(responseColumnIndex).setCellValue("ERROR: " + e.getMessage());
            }
        }

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=result.xlsx")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(outputStream.toByteArray());
    }
}
